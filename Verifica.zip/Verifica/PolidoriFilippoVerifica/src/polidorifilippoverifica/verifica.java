/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package polidorifilippoverifica;

/**
 *
 * @author polidori.filippo
 */
public class PolidoriFilippoVerifica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Evento evento1 = new Evento("Kid Yugi", 55, 43, 98, 1, 100);
        Evento evento2 = new Evento("Kid Yugi", 55, 43, 98, 1, 100);
        
        System.out.println("Il primo e il secondo evento sono lo stesso? " + evento1.equals(evento2));
        System.out.println("Dati evento: " + toString(Evento));
        
    }
    
}

