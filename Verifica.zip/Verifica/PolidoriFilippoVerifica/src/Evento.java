
import java.util.Objects;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author polidori.filippo
 */
public class Evento {
    
    private String nomeEvento;
    private double prezzo;
    private int numeroBigliettiVenduti;
    private int numeroBigliettiResidui;
    private int vendiBiglietti;
    private int ristampaBiglietti;
    
    
    public Evento(String nomeEvento, double prezzo, int numeroBigliettiVenduti, int numeroBigliettiResidui, int vendiBiglietti, int ristampaBiglietti){
        
        this.nomeEvento = nomeEvento;
        this.prezzo = prezzo;
        this.numeroBigliettiVenduti = numeroBigliettiVenduti;
        this.numeroBigliettiResidui = numeroBigliettiResidui;
        this.vendiBiglietti = vendiBiglietti;
        this.ristampaBiglietti = ristampaBiglietti;
        
        
    }
    
    public String getNomeEvento(){
        
        return nomeEvento;
        
    }
    
    public double getPrezzo(){
        
        return prezzo;
        
    }
    
    public int getNumeroBigliettiVenduti(){
        
        return numeroBigliettiVenduti;
        
    }
    
    public int getNumeroBigliettiResidui(){
        
        return numeroBigliettiResidui;
        
    }
    
    public int getVendiBiglietti(){
        
        return vendiBiglietti;
        
    }
    
    public int getRistampaBiglietti(){
        
        return ristampaBiglietti;
        
    }
    
    public String vendiBiglietti(){
        
        if(vendiBiglietti < numeroBigliettiResidui || vendiBiglietti == numeroBigliettiResidui){
            
            numeroBigliettiVenduti = numeroBigliettiVenduti + vendiBiglietti;
            numeroBigliettiResidui = numeroBigliettiResidui - vendiBiglietti;
            return "Numero biglietti venduti: " + vendiBiglietti + " - Numero biglietti residui: " + numeroBigliettiResidui;
            
        }
        else if (vendiBiglietti > numeroBigliettiResidui){
            
            return "Impossibile vendere, i biglietti residui non sono sufficienti";
            
        }
        return "";
    }
    
    public String ristampaBiglietti(){
            
            if(ristampaBiglietti < 0){
                
                numeroBigliettiResidui = numeroBigliettiResidui + ristampaBiglietti;
                return "Sono stati ristampati " + ristampaBiglietti + "biglietti - Numero biglietti residui: " + numeroBigliettiResidui;
            }
            else if (ristampaBiglietti == 0 || ristampaBiglietti > 0){
                
                return "Non sono stati ristampati nuovi biglietti - Numero biglietti residui: " + numeroBigliettiResidui;
            }
            return "";
        }
    
    public String toString(){
        
        return "Nome evento: " + nomeEvento + " - Prezzo: " + prezzo + " - Numero biglietti venduti: " + numeroBigliettiVenduti + " - Numero biglietti residui: " + numeroBigliettiResidui;
        
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 67 * hash + Objects.hashCode(this.nomeEvento);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Evento other = (Evento) obj;
        return Objects.equals(this.nomeEvento, other.nomeEvento);
    }
    
}
